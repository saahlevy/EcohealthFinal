export const ocorrencias: string[] = ['Enchente', 'Queimada', 'Deslizamento', 'Outros'];
